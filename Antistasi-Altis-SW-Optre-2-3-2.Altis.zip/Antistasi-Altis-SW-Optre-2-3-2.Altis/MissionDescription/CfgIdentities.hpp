class CfgIdentities
{
  class protagonista
  {
    name = "Stavros";
    nameSound = "Stavrou";
    face="GreekHead_A3_01";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class friendlyX
  {
    name = "Petros";
    nameSound = "Petros";
    face="GreekHead_A3_01";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class Anthis
  {
    name = "Anthis";
    nameSound = "Anthis";
    face="GreekHead_A3_02";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class Costa
  {
    name = "Costa";
    nameSound = "Costa";
    face="GreekHead_A3_03";
    glasses="None";
    speaker="Male02GRE";
    pitch=1.1;
  };
  class Dimitirou
  {
    name = "Dimitirou";
    nameSound = "Dimitirou";
    face="GreekHead_A3_04";
    glasses="None";
    speaker="Male03GRE";
    pitch=1.1;
  };
  class Elias
  {
    name = "Elias";
    nameSound = "Elias";
    face="GreekHead_A3_05";
    glasses="None";
    speaker="Male04GRE";
    pitch=1.1;
  };
  class Gekas
  {
    name = "Gekas";
    nameSound = "Gekas";
    face="GreekHead_A3_06";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class Kouris
  {
    name = "Kouris";
    nameSound = "Kouris";
    face="GreekHead_A3_07";
    glasses="None";
    speaker="Male02GRE";
    pitch=1.1;
  };
  class Leventis
  {
    name = "Leventis";
    nameSound = "Leventis";
    face="GreekHead_A3_08";
    glasses="None";
    speaker="Male03GRE";
    pitch=1.1;
  };
  class Markos
  {
    name = "Markos";
    nameSound = "Markos";
    face="GreekHead_A3_09";
    glasses="None";
    speaker="Male04GRE";
    pitch=1.1;
  };
  class Nikas
  {
    name = "Nikas";
    nameSound = "Nikas";
    face="WhiteHead_02";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class Nicolo
  {
    name = "Nicolo";
    nameSound = "Nicolo";
    face="WhiteHead_03";
    glasses="None";
    speaker="Male02GRE";
    pitch=1.1;
  };
  class Panas
  {
    name = "Panas";
    nameSound = "Panas";
    face="WhiteHead_04";
    glasses="None";
    speaker="Male03GRE";
    pitch=1.1;
  };
  class Rosi
  {
    name = "Rosi";
    nameSound = "Rosi";
    face="WhiteHead_05";
    glasses="None";
    speaker="Male04GRE";
    pitch=1.1;
  };
  class Samaras
  {
    name = "Samaras";
    nameSound = "Samaras";
    face="WhiteHead_06";
    glasses="None";
    speaker="Male01GRE";
    pitch=1.1;
  };
  class Thanos
  {
    name = "Thanos";
    nameSound = "Thanos";
    face="WhiteHead_07";
    glasses="None";
    speaker="Male02GRE";
    pitch=1.1;
  };
  class Vega
  {
    name = "Vega";
    nameSound = "Vega";
    face="WhiteHead_08";
    glasses="None";
    speaker="Male03GRE";
    pitch=1.1;
  };
};